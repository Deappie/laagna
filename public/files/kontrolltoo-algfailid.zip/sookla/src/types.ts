export type Arvustus = {
  id: number;
  toit: string;
  hinne: number;
  kommentaar: string;
};

export type Soov = {
  id: number;
  toit: string;
  pohjus: string;
};
