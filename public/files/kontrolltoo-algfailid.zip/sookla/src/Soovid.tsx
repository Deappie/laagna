// Toidusoovid. Selle faili kujundus ja olekud on valmis, sinu töö on TODO 4, 5 ja 6.
// Kuni need on tegemata, joonib VS Code mõne muutuja ära ja ütleb, et seda ei kasutata. See on korras ja kaob,
// kui oled koodi kirjutanud. Leht töötab ka enne seda.
import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import type { Soov } from './types';

export default function Soovid() {
  const [soovid, setSoovid] = useState<Soov[]>([]);
  const [laeb, setLaeb] = useState(true);
  const [viga, setViga] = useState('');
  const [toit, setToit] = useState('');
  const [pohjus, setPohjus] = useState('');

  async function laeSoovid() {
    // TODO 4 (2 p): küsi serverilt GET /api/soovid ja pane saadud massiiv olekusse (setSoovid).
    //   Kui server ei vasta, näita viga: setViga('Soove ei saanud kätte. Kas server töötab?').
    //   Lõpuks setLaeb(false). Eeskuju: App.tsx funktsioon laeArvustused.
  }

  useEffect(() => {
    laeSoovid();
  }, []);

  async function lisa(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setViga('');
    // TODO 5 (2 p): saada { toit, pohjus } POST-iga aadressile /api/soovid.
    //   Kui server vastab veaga, näita serveri veateadet: setViga(andmed.viga).
    //   Kui kõik on korras, pane serveri tagastatud kirje nimekirja algusesse ja tühjenda mõlemad lahtrid.
    //   Eeskuju: App.tsx funktsioon lisa.
  }

  async function kustuta(id: number) {
    setViga('');
    // TODO 6 (1 p): saada DELETE-päring aadressile /api/soovid/:id, asendades :id kirje numbriga.
    //   Kui kõik on korras, eemalda kirje ka nimekirjast. Eeskuju: App.tsx funktsioon kustuta.
  }

  return (
    <section>
      <h2>Toidusoovid</h2>

      <form onSubmit={lisa}>
        <input value={toit} onChange={(e) => setToit(e.target.value)} placeholder="Mis toitu soovid?" />
        <input value={pohjus} onChange={(e) => setPohjus(e.target.value)} placeholder="Miks?" />
        <button type="submit">Soovi</button>
      </form>

      {laeb && <p className="kokku">Laen soove…</p>}
      {viga && <p className="kokku">{viga}</p>}

      <ul>
        {soovid.map((x) => (
          <li key={x.id} className="kaart">
            <strong>{x.toit}</strong>
            <p>{x.pohjus}</p>
            <button type="button" onClick={() => kustuta(x.id)}>Kustuta</button>
          </li>
        ))}
      </ul>
    </section>
  );
}
