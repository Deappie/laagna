const express = require('express');

const app = express();

app.use(express.json());

let arvustused = [
  { id: 1, toit: 'Kanakaste riisiga', hinne: 5, kommentaar: 'Parim toit sel nädalal!' },
  { id: 2, toit: 'Hernesupp', hinne: 3, kommentaar: 'Natuke liiga paks.' },
  { id: 3, toit: 'Makaronid hakklihaga', hinne: 4, kommentaar: 'Klassika, alati hea.' },
];
let jargmineId = 4;

app.get('/', (req, res) => {
  res.send('Tere! Söökla server töötab.');
});

app.get('/api/arvustused', (req, res) => {
  res.json(arvustused);
});

app.post('/api/arvustused', (req, res) => {
  const { toit, hinne, kommentaar } = req.body;

  const toitOnKorras = typeof toit === 'string' && toit.trim() !== '';
  const kommentaarOnKorras = typeof kommentaar === 'string' && kommentaar.trim() !== '';
  const hinneOnKorras = Number.isInteger(hinne) && hinne >= 1 && hinne <= 5;

  if (!toitOnKorras || !kommentaarOnKorras || !hinneOnKorras) {
    res.status(400).json({ viga: 'Täida kõik lahtrid, hinne on 1 kuni 5.' });
    return;
  }

  const uus = { id: jargmineId, toit: toit.trim(), hinne, kommentaar: kommentaar.trim() };
  jargmineId = jargmineId + 1;
  arvustused = [uus, ...arvustused];
  res.status(201).json(uus);
});

app.delete('/api/arvustused/:id', (req, res) => {
  const id = Number(req.params.id);
  const leitud = arvustused.find((a) => a.id === id);

  if (!leitud) {
    res.status(404).json({ viga: 'Sellist arvustust pole.' });
    return;
  }

  arvustused = arvustused.filter((a) => a.id !== id);
  res.json(leitud);
});

// ---------------------------------------------------------------- Toidusoovid
let soovid = [
  { id: 1, toit: 'Pitsa', pohjus: 'Kõik söövad seda hea meelega.' },
  { id: 2, toit: 'Seljanka', pohjus: 'Talvel on soe supp parim.' },
];
let jargmineSoovId = 3;

// TODO 1 (1 p): GET /api/soovid annab kõik kirjed.
//   Eeskuju: app.get('/api/arvustused', ...) selle faili alguses.

// TODO 2 (2 p): POST /api/soovid lisab uue kirje.
//   Kui toit või pohjus on puudu või tühi, vasta 400 ja { viga: 'Kirjuta toit ja põhjus.' } ning ära lisa midagi.
//   Muidu tee uus kirje numbriga jargmineSoovId, suurenda jargmineSoovId ühe võrra, pane kirje massiivi algusesse
//   ning vasta 201 ja uue kirjega.
//   Eeskuju: app.post('/api/arvustused', ...). Hinnet siin pole, on ainult kaks teksti.

// TODO 3 (2 p): DELETE /api/soovid/:id kustutab kirje.
//   Kui sellise numbriga kirjet pole, vasta 404 ja { viga: 'Sellist soovi pole.' }.
//   Eeskuju: app.delete('/api/arvustused/:id', ...).

app.get('/api/menyy', (req, res) => {
  res.json(['Hernesupp', 'Kanakaste riisiga', 'Pannkoogid']);
});

app.listen(3000, () => {
  console.log('Server töötab: http://localhost:3000');
});
