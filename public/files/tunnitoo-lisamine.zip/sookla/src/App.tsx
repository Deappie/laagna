import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import type { Arvustus } from './types';
import ArvustuseKaart from './ArvustuseKaart';
import './App.css';

export default function App() {
  const [arvustused, setArvustused] = useState<Arvustus[]>([]);
  const [laeb, setLaeb] = useState(true);
  const [viga, setViga] = useState('');
  const [toit, setToit] = useState('');
  const [hinne, setHinne] = useState(5);
  const [kommentaar, setKommentaar] = useState('');

  async function laeArvustused() {
    try {
      const vastus = await fetch('/api/arvustused');
      if (!vastus.ok) {
        throw new Error('Server vastas veaga');
      }
      const andmed: Arvustus[] = await vastus.json();
      setArvustused(andmed);
    } catch {
      setViga('Arvustusi ei saanud kätte. Kas server töötab?');
    }
    setLaeb(false);
  }

  useEffect(() => {
    laeArvustused();
  }, []);

  function lisa(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const uus: Arvustus = { id: Date.now(), toit, hinne, kommentaar };
    setArvustused([uus, ...arvustused]);
    setToit('');
    setHinne(5);
    setKommentaar('');
  }

  return (
    <main>
      <h1>Söökla arvustused</h1>

      <form onSubmit={lisa}>
        <input value={toit} onChange={(e) => setToit(e.target.value)} placeholder="Mis toit?" />
        <select value={hinne} onChange={(e) => setHinne(Number(e.target.value))}>
          <option value={5}>5 ★</option>
          <option value={4}>4 ★</option>
          <option value={3}>3 ★</option>
          <option value={2}>2 ★</option>
          <option value={1}>1 ★</option>
        </select>
        <input
          value={kommentaar}
          onChange={(e) => setKommentaar(e.target.value)}
          placeholder="Kommentaar"
        />
        <button type="submit">Lisa</button>
      </form>

      {laeb && <p className="kokku">Laen arvustusi…</p>}
      {viga && <p className="kokku">{viga}</p>}

      <ul>
        {arvustused.map((a) => (
          <ArvustuseKaart key={a.id} arvustus={a} />
        ))}
      </ul>
    </main>
  );
}
