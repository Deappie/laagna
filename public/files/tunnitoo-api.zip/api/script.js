// 2. nädal: andmed API-st.
// Eelmise nädala töö on siin juba valmis, et kõik saaksid samast kohast alustada.
// Sinu tänane töö on failis allpool, märgitud sõnaga ÜLESANNE.

const vorm = document.querySelector("#vorm");
const sisend = document.querySelector("#uus");
const loend = document.querySelector("#loend");
const tehtudArv = document.querySelector("#tehtud-arv");
const laeNupp = document.querySelector("#lae");


// Valmis: lisab ühe rea loendisse ja paneb sellele klõpsukuulaja.
function lisaRida(tekst) {
  const rida = document.createElement("li");
  rida.textContent = tekst;
  rida.addEventListener("click", () => {
    rida.classList.toggle("tehtud");
    uuendaTehtud();
  });
  loend.append(rida);
}


// Valmis: vormist tuleb uus ülesanne.
vorm.addEventListener("submit", (event) => {
  event.preventDefault();
  const tekst = sisend.value.trim();
  if (tekst === "") return;
  lisaRida(tekst);
  sisend.value = "";
});


// Valmis: loeb kokku tehtud ülesanded.
function uuendaTehtud() {
  tehtudArv.textContent = document.querySelectorAll(".tehtud").length;
}


// ÜLESANNE 3: too andmed internetist ja kirjuta need konsooli.
// Retsept on konspektis. Aadress: https://jsonplaceholder.typicode.com/todos?_limit=5
async function laeYlesanded() {
  // Sinu kood siia

  // ÜLESANNE 4: pane iga saadud ülesanne lehele.
  // Vihje: käi massiiv for...of-iga läbi ja kutsu iga rea kohta lisaRida(y.title).
}


// Valmis: nupule vajutades käivitub sinu funktsioon.
laeNupp.addEventListener("click", laeYlesanded);
