// Kontrollib, kas sinu serveri /api/kysimused töötab nii, nagu ülesandes kirjas (TODO 1–3).
// Käivita server (cd server, node index.js) ja tee teises terminalis projekti peakaustas: node kontrolli.mjs
// Kontroll lisab ja kustutab ühe testkirje. Pärast kontrolli võid serveri taaskäivitada.
const URL = 'http://localhost:3000/api/kysimused';
let punkte = 0;
let kokku = 0;

function tulemus(ok, tekst, vihje) {
  kokku++;
  if (ok) punkte++;
  console.log((ok ? '  korras  ' : '  VIGA    ') + tekst + (ok || !vihje ? '' : '\n           vihje: ' + vihje));
}

async function paring(meetod, aadress, keha) {
  const seaded = { method: meetod };
  if (keha !== undefined) {
    seaded.headers = { 'Content-Type': 'application/json' };
    seaded.body = JSON.stringify(keha);
  }
  const vastus = await fetch(aadress, seaded);
  let andmed = null;
  try {
    andmed = await vastus.json();
  } catch {}
  return { staatus: vastus.status, andmed };
}

try {
  console.log('TODO 1: GET /api/kysimused');
  const algus = await paring('GET', URL);
  tulemus(algus.staatus === 200 && Array.isArray(algus.andmed) && algus.andmed.length >= 2,
    'vastab 200 ja kirjete massiiviga', 'kas marsruut on olemas ja kas server on pärast muutmist taaskäivitatud?');

  console.log('TODO 2: POST /api/kysimused');
  const uus = await paring('POST', URL, { nimi: 'Kontroll', kysimus: 'Kas see töötab?' });
  const id = uus.andmed && uus.andmed.id;
  tulemus(uus.staatus === 201 && typeof id === 'number', 'õige päring: vastab 201 ja uue kirjega, millel on id',
    'res.status(201).json(uus)');
  const parast = await paring('GET', URL);
  tulemus(Array.isArray(parast.andmed) && parast.andmed[0] && parast.andmed[0].id === id,
    'uus kirje on GET-i vastuses esimene', '[uus, ...massiiv]');
  const tyhi = await paring('POST', URL, { nimi: '', kysimus: 'Midagi' });
  tulemus(tyhi.staatus === 400 && tyhi.andmed && typeof tyhi.andmed.viga === 'string', 'tühi nimi: vastab 400 ja { viga }');
  const puudu = await paring('POST', URL, { nimi: 'Test' });
  tulemus(puudu.staatus === 400, 'kysimus puudub: vastab 400');
  const veel = await paring('GET', URL);
  tulemus(Array.isArray(veel.andmed) && veel.andmed.length === parast.andmed.length,
    'vigaseid kirjeid ei lisatud', 'kas 400 järel on return;?');

  console.log('TODO 3: DELETE /api/kysimused/:id');
  const kustuta = await paring('DELETE', `${URL}/${id}`);
  tulemus(kustuta.staatus === 200, 'olemasolev kirje: vastab 200');
  const lopp = await paring('GET', URL);
  tulemus(Array.isArray(lopp.andmed) && !lopp.andmed.some((x) => x.id === id), 'kustutatud kirjet pole enam GET-i vastuses',
    'Number(req.params.id)');
  const pole = await paring('DELETE', `${URL}/99999`);
  tulemus(pole.staatus === 404 && pole.andmed && typeof pole.andmed.viga === 'string', 'olematu number: vastab 404 ja { viga }');
} catch (e) {
  console.log('\nServeriga ei saanud ühendust. Kas server töötab aadressil http://localhost:3000?');
  process.exit(1);
}

console.log(`\nServeri kontroll: ${punkte}/${kokku} korras. Lehe osa (TODO 4–6) kontrolli brauseris.`);
