export type Arvustus = {
  id: number;
  toit: string;
  hinne: number;
  kommentaar: string;
};

export type Kysimus = {
  id: number;
  nimi: string;
  kysimus: string;
};
