import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import type { Arvustus } from './types';
import ArvustuseKaart from './ArvustuseKaart';
import Kysimused from './Kysimused';
import './App.css';

export default function App() {
  const [arvustused, setArvustused] = useState<Arvustus[]>([]);
  const [laeb, setLaeb] = useState(true);
  const [viga, setViga] = useState('');
  const [toit, setToit] = useState('');
  const [hinne, setHinne] = useState(5);
  const [kommentaar, setKommentaar] = useState('');

  async function laeArvustused() {
    try {
      const vastus = await fetch('/api/arvustused');
      if (!vastus.ok) {
        throw new Error('Server vastas veaga');
      }
      const andmed: Arvustus[] = await vastus.json();
      setArvustused(andmed);
    } catch {
      setViga('Arvustusi ei saanud kätte. Kas server töötab?');
    }
    setLaeb(false);
  }

  useEffect(() => {
    laeArvustused();
  }, []);

  async function lisa(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setViga('');

    try {
      const vastus = await fetch('/api/arvustused', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ toit, hinne, kommentaar }),
      });
      const andmed = await vastus.json();

      if (!vastus.ok) {
        setViga(andmed.viga);
        return;
      }

      setArvustused((praegused) => [andmed, ...praegused]);
      setToit('');
      setHinne(5);
      setKommentaar('');
    } catch {
      setViga('Serveriga ei saanud ühendust. Kas server töötab?');
    }
  }

  async function kustuta(id: number) {
    setViga('');

    try {
      const vastus = await fetch(`/api/arvustused/${id}`, { method: 'DELETE' });
      const andmed = await vastus.json();

      if (!vastus.ok) {
        setViga(andmed.viga);
        return;
      }

      setArvustused((praegused) => praegused.filter((a) => a.id !== id));
    } catch {
      setViga('Serveriga ei saanud ühendust. Kas server töötab?');
    }
  }

  return (
    <main>
      <h1>Söökla arvustused</h1>

      <form onSubmit={lisa}>
        <input value={toit} onChange={(e) => setToit(e.target.value)} placeholder="Mis toit?" />
        <select value={hinne} onChange={(e) => setHinne(Number(e.target.value))}>
          <option value={5}>5 ★</option>
          <option value={4}>4 ★</option>
          <option value={3}>3 ★</option>
          <option value={2}>2 ★</option>
          <option value={1}>1 ★</option>
        </select>
        <input
          value={kommentaar}
          onChange={(e) => setKommentaar(e.target.value)}
          placeholder="Kommentaar"
        />
        <button type="submit">Lisa</button>
      </form>

      {laeb && <p className="kokku">Laen arvustusi…</p>}
      {viga && <p className="kokku">{viga}</p>}

      <ul>
        {arvustused.map((a) => (
          <ArvustuseKaart key={a.id} arvustus={a} kustuta={kustuta} />
        ))}
      </ul>

      <Kysimused />
    </main>
  );
}
