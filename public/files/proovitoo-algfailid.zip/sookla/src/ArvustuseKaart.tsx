import type { Arvustus } from './types';

type Props = {
  arvustus: Arvustus;
  kustuta: (id: number) => void;
};

export default function ArvustuseKaart({ arvustus, kustuta }: Props) {
  const tahed = '★'.repeat(arvustus.hinne) + '☆'.repeat(5 - arvustus.hinne);
  return (
    <li className="kaart">
      <div className="kaart-pea">
        <strong>{arvustus.toit}</strong>
        <span className="tahed">{tahed}</span>
      </div>
      <p>{arvustus.kommentaar}</p>
      <button type="button" onClick={() => kustuta(arvustus.id)}>Kustuta</button>
    </li>
  );
}
