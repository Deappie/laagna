// Küsimused kokale. Selle faili kujundus ja olekud on valmis, sinu töö on TODO 4, 5 ja 6.
// Kuni need on tegemata, joonib VS Code mõne muutuja ära ja ütleb, et seda ei kasutata. See on korras ja kaob,
// kui oled koodi kirjutanud. Leht töötab ka enne seda.
import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import type { Kysimus } from './types';

export default function Kysimused() {
  const [kysimused, setKysimused] = useState<Kysimus[]>([]);
  const [laeb, setLaeb] = useState(true);
  const [viga, setViga] = useState('');
  const [nimi, setNimi] = useState('');
  const [kysimus, setKysimus] = useState('');

  async function laeKysimused() {
    // TODO 4 (2 p): küsi serverilt GET /api/kysimused ja pane saadud massiiv olekusse (setKysimused).
    //   Kui server ei vasta, näita viga: setViga('Küsimusi ei saanud kätte. Kas server töötab?').
    //   Lõpuks setLaeb(false). Eeskuju: App.tsx funktsioon laeArvustused.
  }

  useEffect(() => {
    laeKysimused();
  }, []);

  async function lisa(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setViga('');
    // TODO 5 (2 p): saada { nimi, kysimus } POST-iga aadressile /api/kysimused.
    //   Kui server vastab veaga, näita serveri veateadet: setViga(andmed.viga).
    //   Kui kõik on korras, pane serveri tagastatud kirje nimekirja algusesse ja tühjenda mõlemad lahtrid.
    //   Eeskuju: App.tsx funktsioon lisa.
  }

  async function kustuta(id: number) {
    setViga('');
    // TODO 6 (1 p): saada DELETE-päring aadressile /api/kysimused/:id, asendades :id kirje numbriga.
    //   Kui kõik on korras, eemalda kirje ka nimekirjast. Eeskuju: App.tsx funktsioon kustuta.
  }

  return (
    <section>
      <h2>Küsi kokalt</h2>

      <form onSubmit={lisa}>
        <input value={nimi} onChange={(e) => setNimi(e.target.value)} placeholder="Sinu nimi" />
        <input value={kysimus} onChange={(e) => setKysimus(e.target.value)} placeholder="Sinu küsimus" />
        <button type="submit">Küsi</button>
      </form>

      {laeb && <p className="kokku">Laen küsimusi…</p>}
      {viga && <p className="kokku">{viga}</p>}

      <ul>
        {kysimused.map((x) => (
          <li key={x.id} className="kaart">
            <strong>{x.nimi}</strong>
            <p>{x.kysimus}</p>
            <button type="button" onClick={() => kustuta(x.id)}>Kustuta</button>
          </li>
        ))}
      </ul>
    </section>
  );
}
