// Tunnitöö: ülesannete nimekiri
// Ava index.html brauseris ja ava ka konsool (F12 → Console).
// Sinna ilmuvad vead ja kõik, mida console.log välja kirjutab.

// Leiame lehelt vajalikud elemendid. Selektorid on samad mis CSS-is.
const vorm = document.querySelector("#vorm");
const sisend = document.querySelector("#uus");
const loend = document.querySelector("#loend");
const tehtudArv = document.querySelector("#tehtud-arv");


// ÜLESANNE 7: kui vorm saadetakse, lisa sisendi tekst loendisse uue <li>-na.
// Vihjed: event.preventDefault(), document.createElement("li"), textContent, loend.append(...)
// Pärast lisamist tühjenda sisendväli: sisend.value = "".
vorm.addEventListener("submit", (event) => {
  // Sinu kood siia

  // ÜLESANNE 8: kui ülesandel klõpsatakse, märgi see tehtuks.
  // Vihje: lisa uuele <li>-le siinsamas klõpsukuulaja ja kasuta classList.toggle("tehtud").
  // Pärast iga muutust kutsu välja uuendaTehtud().
});


// ÜLESANNE 9: näita lehel, mitu ülesannet on tehtud.
// Vihje: document.querySelectorAll(".tehtud").length annab tehtud ülesannete arvu.
function uuendaTehtud() {
  // Sinu kood siia
}


// ÜLESANNE 10: ära lisa ülesannet, mis koosneb ainult tühikutest.
// Vihje: sisend.value.trim() eemaldab teksti algusest ja lõpust tühikud.
