import type { Arvustus } from './types';

type Props = {
  arvustus: Arvustus;
};

export default function ArvustuseKaart({ arvustus }: Props) {
  const tahed = '★'.repeat(arvustus.hinne) + '☆'.repeat(5 - arvustus.hinne);
  return (
    <li className="kaart">
      <div className="kaart-pea">
        <strong>{arvustus.toit}</strong>
        <span className="tahed">{tahed}</span>
      </div>
      <p>{arvustus.kommentaar}</p>
    </li>
  );
}
