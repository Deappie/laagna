import { useState } from 'react';
import type { FormEvent } from 'react';
import type { Arvustus } from './types';
import { naidisArvustused } from './andmed';
import ArvustuseKaart from './ArvustuseKaart';
import './App.css';

export default function App() {
  const [arvustused, setArvustused] = useState<Arvustus[]>(naidisArvustused);
  const [toit, setToit] = useState('');
  const [hinne, setHinne] = useState(5);
  const [kommentaar, setKommentaar] = useState('');

  function lisa(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const uus: Arvustus = { id: Date.now(), toit, hinne, kommentaar };
    setArvustused([uus, ...arvustused]);
    setToit('');
    setHinne(5);
    setKommentaar('');
  }

  return (
    <main>
      <h1>Söökla arvustused</h1>

      <form onSubmit={lisa}>
        <input value={toit} onChange={(e) => setToit(e.target.value)} placeholder="Mis toit?" />
        <select value={hinne} onChange={(e) => setHinne(Number(e.target.value))}>
          <option value={5}>5 ★</option>
          <option value={4}>4 ★</option>
          <option value={3}>3 ★</option>
          <option value={2}>2 ★</option>
          <option value={1}>1 ★</option>
        </select>
        <input
          value={kommentaar}
          onChange={(e) => setKommentaar(e.target.value)}
          placeholder="Kommentaar"
        />
        <button type="submit">Lisa</button>
      </form>

      <ul>
        {arvustused.map((a) => (
          <ArvustuseKaart key={a.id} arvustus={a} />
        ))}
      </ul>
    </main>
  );
}
