export type Arvustus = {
  id: number;
  toit: string;
  hinne: number;
  kommentaar: string;
};
