const express = require('express');

const app = express();

const arvustused = [
  { id: 1, toit: 'Kanakaste riisiga', hinne: 5, kommentaar: 'Parim toit sel nädalal!' },
  { id: 2, toit: 'Hernesupp', hinne: 3, kommentaar: 'Natuke liiga paks.' },
  { id: 3, toit: 'Makaronid hakklihaga', hinne: 4, kommentaar: 'Klassika, alati hea.' },
];

app.get('/', (req, res) => {
  res.send('Tere! Söökla server töötab.');
});

app.get('/api/arvustused', (req, res) => {
  res.json(arvustused);
});

app.get('/api/menyy', (req, res) => {
  res.json(['Hernesupp', 'Kanakaste riisiga', 'Pannkoogid']);
});

app.listen(3000, () => {
  console.log('Server töötab: http://localhost:3000');
});
